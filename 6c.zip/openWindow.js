function openWindow(url, name) {
  popupWin = window.open(url, name, 'scrollbars,width=640,height=480,left=100,top=100')
}
