var winOpts = 'resizeable=no,scrollbars=yes,width=400,height=300';

function popUp(pPage) {
 popUpWin = window.open(pPage,'popWin',winOpts);
 }
