function pr(n) {
	document.write(n,"\n");
	}